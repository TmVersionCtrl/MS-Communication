package com.conacent;

public class TestClass {

	public static void main(String[] args) {
		
		A d = new D();
		d.methodA();
		
		A c = new C();
		c.methodA();
		
		//G is for Exceptions
		G g = new G();
		
		try {
			g.throwCheckedException();
		} catch (Exception e) {
			System.err.println("Inside checked exception");
		}
		finally {
			System.out.println("For cleanUp operations inside finally.");
		}
		
		try {
			g.throwUnCheckedException();
		} catch(RuntimeException e) {
			System.err.println("Handling unchecked Exception");
		}
		finally {
			System.out.println("After handling unchecked exception.");
		}
		
		g.throwUnCheckedException("Runtime exception not handled.");
	}
	
}
