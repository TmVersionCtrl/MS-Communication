package com.conacent;

public abstract class B extends A{
	
	public abstract void show();
	
}
