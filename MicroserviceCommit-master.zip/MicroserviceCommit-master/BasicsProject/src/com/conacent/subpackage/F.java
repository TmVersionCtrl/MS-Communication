package com.conacent.subpackage;

import com.conacent.E;

public class F extends E {

	@Override
	public void show() {
		System.out.println("In F.");
	}

	
	
}
