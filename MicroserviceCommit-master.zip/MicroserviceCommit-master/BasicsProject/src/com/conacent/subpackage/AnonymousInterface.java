package com.conacent.subpackage;

@FunctionalInterface
public interface AnonymousInterface {

	public void methodA();
	
}
