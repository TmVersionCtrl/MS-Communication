package com.conacent.subpackage;

public class BasicClassSructure {

	public static void main(String[] args) {
		
		//anonymous class
		AnonymousInterface anonymousInterface = new AnonymousInterface() {
			
			@Override
			public void methodA() {
				System.out.println("Inside Anonymous class.");
			}
		};
		
		anonymousInterface.methodA();
		
		AnonymousInterface innerClass = new InnerClass();
		innerClass.methodA();
		
		BasicClassSructure.StaticInnerClass staticInner = new BasicClassSructure.StaticInnerClass();
		staticInner.methodA();
		
		BasicClassSructure clazz = new BasicClassSructure();
		clazz.methodToInvokeLocalClass();
		
	}
	
	public void methodToInvokeLocalClass() {
		
		class LocalInnerClass implements AnonymousInterface{

			@Override
			public void methodA() {
				System.out.println("Inside local Inner Class.");
			}
		}
		
		LocalInnerClass localClazz = new LocalInnerClass();
		localClazz.methodA();
		
	}
	
	public static class StaticInnerClass implements AnonymousInterface{

		@Override
		public void methodA() {
			System.out.println("Inside Static Inner Class");
		}
	}
}

class InnerClass implements AnonymousInterface{

	@Override
	public void methodA() {
		System.out.println("Inside Inner Class.");
	}}
