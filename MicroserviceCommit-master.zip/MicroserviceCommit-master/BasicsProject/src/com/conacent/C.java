package com.conacent;

public class C extends A{

	@Override
	public void methodA() {
		System.out.println("In C");
	}
	
}
