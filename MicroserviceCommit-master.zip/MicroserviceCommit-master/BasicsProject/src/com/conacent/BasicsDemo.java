package com.conacent;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class BasicsDemo {

	public static void main(String[] args) throws IOException {

//		dateTimeWork();
//		basicRegExp();
//		basicFileHandling();
//		basicArrays();
//		basicCollections();
		
	}
	
	private static void basicCollections() {
		List<Integer> lst = new ArrayList<>();
		lst.add(1);
		lst.add(2);
		lst.add(3);
		lst.remove(2);
		lst.add(1, 4);

		System.out.println(lst);

		lst = Arrays.asList(1, 2, 3, 2);
//		lst.remove(1);		throws error @runtime
		System.out.println(lst);

		List<Integer> ll = new LinkedList<>();
		ll.add(0);
		ll.add(1);
		ll.add(2);

		System.out.println(ll);

		Set<Integer> st = lst.stream().collect(Collectors.toSet());
		System.out.println(st);

		Set<Integer> treeSet = new TreeSet<>();
		for (int n : st)
			treeSet.add(n);

		System.out.println(treeSet);

		Map<Character, Integer> hMap = new HashMap<>();
		Map<Character, Integer> treeMap = new TreeMap<>();

		for (int n : st) {
			if (hMap.containsKey((char) (n + 96))) {
				hMap.put((char) (n + 96), hMap.get((char) (n + 96)) + 1);
				treeMap.put((char) (n + 96), treeMap.get((char) (n + 96)) + 1);
			} else {
				char c = (char) (n + 96);
				hMap.put(c, 1);
				treeMap.put(c, 1);
			}
		}
	}


	private static void basicArrays() {
		int[] arr1 = new int[] {1,2,4};
		int[] arr2 = {1,2,3,4,5};
		
		
		
		System.out.println(Arrays.toString(arr2));
		System.out.println(Arrays.toString(arr1));
	}

	private static void basicRegExp() {
		
		// String to be scanned to find the pattern.
	    String line = "This order was placed for QT3000! OK?";
	    String pattern = "(.*Q)";
	    Pattern r = Pattern.compile(pattern);
	    Matcher m = r.matcher(line);
	    if(m.find()) {
	    	System.out.println(m.group());
	    }
	}

	private static void dateTimeWork() {
		
		Date utilDt = new Date();
		long currentTime = System.currentTimeMillis();
		currentTime+=864000;
		Date utilDt1 = new Date(currentTime);
		System.out.println(utilDt+" || "+utilDt1+" || "+utilDt1.compareTo(utilDt));
		
		Date sqlDt = new java.sql.Date(currentTime);
		System.out.println(sqlDt);
		
		LocalDate localDate = LocalDate.now();
		System.out.println(localDate.plusDays(10));
		System.out.println(localDate.plusMonths(10));
		
		SimpleDateFormat sdf = new SimpleDateFormat("G y:MM:dd | hh:mm:ss:S a");
		System.out.println(sdf.format(utilDt));
		
		//paring String to Date
		String givenDT = "16/03/23";
		SimpleDateFormat format = new SimpleDateFormat("dd:MM:yy");
		Date parsedDT = null;
		
		try {
			parsedDT = format.parse(givenDT);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		System.out.println(parsedDT);
		
	}

	private static void basicFileHandling() throws IOException {
		
		File f = new File("src/readThis.csv");
		boolean flag = true;
		
		FileInputStream inp = null;
		
		try {
			
			inp = new FileInputStream(f);
			System.out.println("Using FileInputStream:"+inp.read());
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(inp!=null)
				inp.close();
		}
		
		FileReader inReader = null;
		
		try {
			inReader = new FileReader(f);
			System.out.println("Using FileReader :"+inReader.read());
			
			int byteRead;
//			while((byteRead=inReader.read())!=-1) {
//				System.out.println(byteRead);
//			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(inReader!=null)
				inReader.close();
		}
		
		String name = "D:\\"+System.currentTimeMillis()+".csv";
		try(BufferedReader in = 
				new BufferedReader(new InputStreamReader(
						new FileInputStream(f)));
				BufferedWriter out = 
						new BufferedWriter(new OutputStreamWriter(
							new FileOutputStream(name)))){
			
			String line = null;
			in.readLine();
			while((line=in.readLine())!=null){
				if(flag) {
					System.out.println(line);
					out.append(line);
					flag =false;
				}
				
				else		break;
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		File newFile = new File(name);
		
		try {
			
			Thread.sleep(10000);
			
			if(newFile.delete())
				System.out.println("File deleted.");
			else
				System.out.println("Not deleted");
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		flag = true;
		
		try(Scanner in = new Scanner(f)){
			in.useDelimiter(".*\\n");
			
			while(in.hasNext() && flag) {
				System.out.print(in.next()+" "+in.next());
				flag=false;
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		

	}
}
