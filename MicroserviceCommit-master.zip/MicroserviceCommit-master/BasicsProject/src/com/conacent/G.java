package com.conacent;

public class G {
	
	public void throwCheckedException() throws Exception {
		throw new Exception();
	}
	
	public void throwUnCheckedException() {
		throw new RuntimeException();
	}
	
	public void throwUnCheckedException(String msg) {
		throw new RuntimeException(msg);
	}
	
}
