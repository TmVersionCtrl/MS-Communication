package com.conacent.problem;

public interface Shape {

	public void calculateArea();
	
}
