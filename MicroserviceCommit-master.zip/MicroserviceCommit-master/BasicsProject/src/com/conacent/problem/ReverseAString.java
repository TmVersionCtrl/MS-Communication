package com.conacent.problem;

public class ReverseAString {

	private String s,reversedS;

	public ReverseAString(String s) {
		this.s = s;
		reversedS = reverseString();
	}

	public String getString() {
		return s;
	}
	
	public String getReversedS() {
		return reversedS;
	}

	public String reverseString() {
		
		StringBuilder sb = new StringBuilder();
		
		for(int i=s.length()-1;i>=0;i--)
			sb.append(s.charAt(i));
		
		return sb.toString();
	}
	
}
