package com.conacent.problem;

public class Rectangle implements Shape {

	private int l,b;
	private double area;

	public Rectangle(int l, int b) {
		super();
		this.l = l;
		this.b = b;
	}

	public int getLength() {
		return l;
	}

	public int getBreath() {
		return b;
	}

	public double getArea() {
		return area;
	}

	@Override
	public void calculateArea() {
		area = l*b;
	}
}
