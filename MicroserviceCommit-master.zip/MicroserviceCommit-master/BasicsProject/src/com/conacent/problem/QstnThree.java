package com.conacent.problem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class QstnThree {

	private List<Integer> list;
	private int size;
	public Map<Integer, Integer> noCount;

	public QstnThree(int size) {
		this.size = size;
		this.list = new ArrayList<>(size);
	}

	public List<Integer> getList() {
		return list;
	}

	public void fillList() {

		Random random = new Random();
		
		for (int i = 0; i < size; i++) {
			list.add(random.nextInt(100));
		}
	}

	public Map<Integer, Integer> getCount() {
		if (this.noCount != null)
			return noCount;
		noCount = new HashMap<>();

		for (int n : list)
			noCount.put(n, noCount.getOrDefault(n, 0) + 1);

		return noCount;
	}

}
