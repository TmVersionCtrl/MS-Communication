package com.conacent.problem;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashMapToArray {

	private Map<Integer, String> map;
	private List<User> users;

	public HashMapToArray() {
		this.map = new HashMap<>();
	}

	public void convert() {
		for (int k : map.keySet())
			users.add(new User(k, map.get(k)));
	}

	public void print() {
		System.out.println(users);
	}

}

class User {

	private int id;
	private String name;

	public User(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + "]";
	}

}
