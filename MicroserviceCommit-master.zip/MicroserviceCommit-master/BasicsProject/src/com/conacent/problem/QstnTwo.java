package com.conacent.problem;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QstnTwo {

	private int[] arr;

	public QstnTwo(int size) {
		this.arr = new int[size];
	}

	public void fillArray() {
		Random random = new Random();
		for (int i = 0; i < arr.length; i++)
			arr[i] = random.nextInt(100);

	}

	public int[] getArr() {
		return arr;
	}

	public List<Tuple> getCount() {
		List<Tuple> lst = new ArrayList<>();

		Tuple dummyTup = new Tuple(-1, 0);

		for (int n : arr) {

			boolean flag = true;

			for (int i = 0; i < lst.size(); i++) {
				Tuple t = lst.get(i);
				if (t.equals(dummyTup.setData(n))) {
					lst.add(i, t.setNo(t.getNo() + 1));		//L
					flag = false;
					break;
				}
			}

			if (flag)
				lst.add(new Tuple(n, 1));
		}

		return lst;

//		for(int n:arr) {
//			if(lst.get(n%arr.length).getNo()!=n) {
//				int ind = 0;
//				while(ind<)
//			}
//			else {
//				int data = lst.get(n%arr.length).getData();
//				data+=1;
//				lst.add(n%arr.length,new Tuple(data,n));
//			}
//		}

	}

}

class Tuple {

	private int data, no;

	public Tuple(int data, int no) {
		super();
		this.data = data;
		this.no = no;
	}

	public Tuple setData(int data) {
		this.data = data;
		return this;
	}

	public Tuple setNo(int no) {
		this.no = no;
		return this;
	}

	public int getData() {
		return data;
	}

	public int getNo() {
		return no;
	}

	@Override
	public boolean equals(Object obj) {
		Tuple t = (Tuple) obj;
		return data == t.data;
	}

	@Override
	public String toString() {
		return "Tuple [data=" + data + ", no=" + no + "]";
	}

}
