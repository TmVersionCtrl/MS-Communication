package com.conacent.problem;

public class ShapeMain {

	public static void main(String[] args) {
		
		Shape rect = new Rectangle(10, 20);
		rect.calculateArea();
		System.out.println();
		
	}
	
}
