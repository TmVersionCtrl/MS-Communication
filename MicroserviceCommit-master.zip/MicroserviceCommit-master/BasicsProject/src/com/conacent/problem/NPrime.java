package com.conacent.problem;

public class NPrime {

	int np;

	public NPrime(int np) {
		super();
		this.np = np;
	}
	
	public boolean isPrime() {
		for(int i=2;i*i<=np;i++) {
			if(np%i==0)
				return false;
		}
		
		return true;
	}
	
}
