package com.conacent.problem;

public class ReverseANumber {

	private int no, revNo;

	public ReverseANumber(int no) {
		this.no = no;
		this.revNo = reverse();
	}

	private int reverse() {

		int tmp = no, sum = 0;
		while (tmp != 0) {	
			sum=sum*10+(tmp%10);	
			tmp /= 10;	
		}

		return sum;
	}

	public int getNo() {
		return no;
	}

	public int getRevNo() {
		return revNo;
	}

}
