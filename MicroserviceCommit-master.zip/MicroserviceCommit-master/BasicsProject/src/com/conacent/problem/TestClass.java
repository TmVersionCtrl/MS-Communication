package com.conacent.problem;

import java.util.Arrays;

public class TestClass {

	public static void main(String[] args) {
		
		NPrime np = null;
		for(int i=1;i<=10;i++) {
			np = new NPrime(i);
			if(np.isPrime())
				System.out.println("\t"+i+" is Prime.");
			else
				System.out.println("\t"+i+" is not prime.");
		}
		
		QstnTwo two = new QstnTwo(2);
		two.fillArray();
		System.out.println(Arrays.toString(two.getArr()));
		System.out.println(two.getCount());
		
		
		QstnThree q3 = new QstnThree(10);
		q3.fillList();
		System.out.println(q3.getList());
		System.out.println(q3.getCount());
		
		ReverseAString revString = new ReverseAString("Hello");
		System.out.println(revString.getReversedS());
		
		ReverseANumber revNo = new ReverseANumber(10);
		System.out.println(revNo.getRevNo());
//		
		Factorial f = new Factorial(5);
		System.out.println(f.getFact());
		
	}
	
}
