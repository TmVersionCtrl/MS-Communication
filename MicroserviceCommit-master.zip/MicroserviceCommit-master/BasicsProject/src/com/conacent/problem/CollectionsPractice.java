package com.conacent.problem;

public class CollectionsPractice {

	public static void maps() {
		
	}
	
}
