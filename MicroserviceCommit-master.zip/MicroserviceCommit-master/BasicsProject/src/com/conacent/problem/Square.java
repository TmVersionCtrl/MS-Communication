package com.conacent.problem;

public class Square implements Shape {

	private int side;
	
	private double area;

	public Square(int side) {
		super();
		this.side = side;
	}

	public int getSide() {
		return side;
	}

	public double getArea() {
		return area;
	}

	@Override
	public void calculateArea() {
		area = side*side;
	}
	
}
