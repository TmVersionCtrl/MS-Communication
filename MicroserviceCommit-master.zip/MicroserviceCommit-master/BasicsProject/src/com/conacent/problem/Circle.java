package com.conacent.problem;

import static java.lang.Math.PI;

public class Circle implements Shape {

	private int r;
	private double area;

	public Circle(int r) {
		super();
		this.r = r;
	}

	public int getRadius() {
		return r;
	}

	public double getArea() {
		return area;
	}

	@Override
	public void calculateArea() {
		area = PI * r * r;
	}

}
