package com.conacent.problem;

public class Factorial {

	private int no;
	private int fact;

	public Factorial(int no) {
		super();
		this.no = no;
		this.fact = calculateFact();
	}

	private int calculateFact() {
		return factorialBYRecursion(no);
	}

	private int factorialBYRecursion(int no) {
		if (no <= 0)
			return 1;
		return no * factorialBYRecursion(no - 1);
	}

	public int getNo() {
		return no;
	}

	public int getFact() {
		return fact;
	}

}
