package com.conacent;

public class D extends B{

	@Override
	public void show() {
		System.out.println("In show of D.");
	}
	
	
}
