package com.conacent;

public class A {
	
	private int x = 10;
	
	public void methodA() {
		System.out.println(x+" In A.");
	}
	
}
