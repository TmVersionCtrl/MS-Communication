package com.conacent;

public class E {

	protected void show() {
		System.out.println("In E");
	}
	
}
