package com.streams;

public class Marks {

	private int marks;
	private int studentId;
	private String deptName;

	public Marks(int marks, int studentId, String deptName) {
		super();
		this.marks = marks;
		this.studentId = studentId;
		this.deptName = deptName;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	

}
