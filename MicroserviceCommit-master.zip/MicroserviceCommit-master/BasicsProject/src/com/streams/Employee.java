package com.streams;

import java.util.Comparator;

public class Employee {

	public static class SortBySalary implements Comparator<Employee> {

		@Override
		public int compare(Employee o1, Employee o2) {
			return o1.salary - o2.salary;
		}

	}

	String name;
	int salary;

	public Employee(String name, int salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + "]";
	}

}
