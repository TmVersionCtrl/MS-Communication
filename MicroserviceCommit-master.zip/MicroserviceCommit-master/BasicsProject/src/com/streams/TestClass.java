package com.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestClass {

	public static void main(String[] args) {
		
		List<Employee> lst = Arrays.asList(new Employee[] {new Employee("JJ",200),new Employee("kk", 50),
				new Employee("sagar", 1000)});
		
//		Collections.sort(lst,new Employee.SortBySalary());
//		System.out.println(lst);
		
		//Multiple ways to sort a list with streams
		List<Employee> list = lst.stream().sorted(new Employee.SortBySalary())
				.collect(Collectors.toList());
		System.out.println(list);
		
		List<Employee> collect = lst.stream().sorted((o1,o2)->o1.name.length()-o2.name.length())
				.collect(Collectors.toList());
		System.out.println(collect);
		
		List<Marks> marks = Arrays.asList(new Marks[] {new Marks(75,1212,"EE"),
				new Marks(65, 1111, "EE"),new Marks(62, 1331, "CSE"),new Marks(85, 1444, "CSE")});
		
		Map<String, List<Marks>> collect2 = marks.stream().collect(Collectors.groupingBy(Marks::getDeptName));
		collect2.entrySet().forEach(e->{
			List<Marks> l=e.getValue();
			System.out.println(l.stream().map(Marks::getMarks).max((o1,o2)->o1-o2));
			} );
		
		
		
		
	}
	
}
