package com.data_structures;

public class TestClass {

	public static void main(String[] args) {
		StackQueue<Integer> s = new StackQueue<>();
		s.push(1);
		s.push(2);
		s.push(3);
		
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.pop());
		
		StackQueue<Integer> q = new StackQueue<>();
		q.enqueue(1);
		q.enqueue(2);
		q.enqueue(3);
		
		q.print();
		
		System.out.println(q.dequeue());
		System.out.println(q.dequeue());
		System.out.println(q.dequeue());
	}
	
}
