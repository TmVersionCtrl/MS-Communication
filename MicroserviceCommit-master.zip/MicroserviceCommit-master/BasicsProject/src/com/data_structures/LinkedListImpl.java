package com.data_structures;

public class LinkedListImpl<T> implements ILinkedList<T> {
	
	private Node<T> head,current;
	private int size;

	@Override
	public void print() {
		Node<T> tmp = head;
		
		while(tmp.next!=null) {
			System.out.println(tmp.t+"->");
			tmp = tmp.next;
		}
		
		System.out.println(tmp.t);
	}

	@Override
	public boolean addFirst(T t) {
		
		if(head==null) {
			head=new Node<T>(t);
			current = head;
			size=1;
		}
		else {
			Node<T> tmp = new Node<T>(t);
			tmp.next = head;
			head = tmp;
			size++;
		}
		
		return true;
	}

	@Override
	public boolean addLast(T t) {
		
		if(head==null) {
			head = new Node<T>(t);
			current = head;
			size=1;
		}
		else {
			Node<T> tmp = new Node<T>(t);
			current.next = tmp;
			current = current.next;
			size++;
		}
		
		return true;
	}

	@Override
	public boolean addAtPos(T t, int pos) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T removeFirst() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T removeLast() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T removeAtPos(int pos) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeAll() {
		// TODO Auto-generated method stub
		
	}
	
}

class Node<T>{
	
	T t;
	Node<T> next;
	
	public Node(T t) {
		this.t = t;
		this.next = null;
	}
	
}