package com.data_structures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class StackQueue<T> {

	private List<T> innrList;

	public StackQueue() {
		this.innrList = new LinkedList<>();
	}

	public boolean push(T t) {
		innrList.add(t);
		return true;
	}

	public T pop() {
		T data = innrList.remove(innrList.size() - 1);
		return data;
	}

	public T top() {
		return innrList.get(innrList.size() - 1);
	}

	public boolean enqueue(T t) {
		innrList.add(0, t);
		return true;
	}

	public T dequeue() {
		return innrList.remove(0);
	}

	public T peek() {
		return innrList.get(0);
	}

	public void print() {
		System.out.println(innrList);
	}

}
