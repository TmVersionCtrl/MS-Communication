package com.data_structures;

public interface ILinkedList<T> {
	
	public void print();
	
	public boolean addFirst(T t);
	
	public boolean addLast(T t);
	
	public boolean addAtPos(T t,int pos);
	
	public T removeFirst();
	
	public T removeLast();
	
	public T removeAtPos(int pos);
	
	public void removeAll();
	
}
